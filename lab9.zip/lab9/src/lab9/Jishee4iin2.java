package lab9;

public class Jishee4iin2 {
	public static void main(String[] args) {
		int age = 28;
		assert age >= 18 : "Санал өгч болохгүй";
		System.out.println("Иргэний нас нь: " + age);
	}

}
