package lab9;

public class jishe2iin2
{
	public static void main(String[] args)
	{
		int x = 8;
		assert x >= 0: "Тоо 0-ээс их буюу тэнцүү байх ёстой!";
		System.out.println("Өгөгдсөн тоо=: " + x);
	}
}
