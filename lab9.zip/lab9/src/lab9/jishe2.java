package lab9;

public class jishe2 
{
	public static void main(String[] args)
	{
			int x = -1;
			assert x >= 0: "x < 0 ө.х-ийн утга 0-ээс бага байна!";
	}
}