package lab9;

public class jishe1
{

	public static void main(String[] args)
			{
				int x = -1;
				assert x >= 0;
			}
}