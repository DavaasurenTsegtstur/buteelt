package lab9;

public class Jishee2iin1 
{
	public static void main(String[] args)
	{
		int x = -1;
		assert x >= 0: "Тоо 0-ээс их буюу тэнцүү байх ёстой!";
		System.out.println("Өгөгдсөн тоо=: " + x);
	}
}
