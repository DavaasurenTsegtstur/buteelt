package lab9;

public class jishee1 {

	public int add(int x, int y) {
		return x + y;
	}
}
